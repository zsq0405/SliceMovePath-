#include"SliceMovePath.h"
#include"global.h"
//������е�λ����
bool ReadFile(std::string open_file_path, std::vector<double>& all_point, int* all_num_point)
{
	//��ȡtxt�ļ��еĵ�λ����
	std::ifstream infile(open_file_path);//�ı��ĵ�·��
	if (infile.is_open())
	{
		std::cout << " file is opened successfully" << std::endl;
	}
	else
	{
		std::cout << " file is opened error" << std::endl;
	}
	std::vector<std::string>s_txt;
	std::vector<std::string>::iterator it;
	std::string str;
	while (infile >> str)
	{
		s_txt.push_back(str);
	}//�ı�������


	double s_num;
	std::string s;

	int i = 0;
	//�ϲ�����str
	for (it = s_txt.begin(); it != s_txt.end(); it++) {
		if (it == s_txt.begin()) {
			s = *it;
		}
		else
		{
			s = s + "," + *it;
		}
	}
	std::cout << s << std::endl;
	std::string s_temp = s;
	//��ȡtxt�ĵ��е�����
	auto dot_num = [&](size_t current_pos) {
		int times = 0;
		for (size_t i = current_pos; i < s.size(); i++)
		{
			if (s[i] == ',') { times++; }
		}
		return times;
	};

	*all_num_point = dot_num(0) + 1;//��õ�λ����������X+����Y+����Z��=��������+1��

	if (*all_num_point % 3 != 0)
	{
		std::cout << "warning:��λ����������Ҫ��" << std::endl;
		return false;
	}
	else
	{
		std::cout << "��λ��������Ҫ��" << std::endl;
	}

	size_t all_index = dot_num(0);//������ж�������

	size_t last_index = s.size();
	size_t current_index = s.find_first_of(',');
	while (current_index != std::string::npos)
	{
		current_index = s.find_first_of(',');
		if (current_index != std::string::npos)
		{

			s_temp = s.substr(0, current_index);
			s_num = std::stod(s_temp);//��string����תΪdouble
			all_point.push_back(s_num);
			s = s.substr(current_index + 1, s.size());
		}
		else
		{
			s_num = std::stod(s);
			all_point.push_back(s_num);
		}
	}

	infile.close();
	return true;
}
bool WriteFile(std::string save_file_path, std::vector<double>x_temp, std::vector<double>y_temp, std::vector<double>z_temp)
{
	if (x_temp.size()!= y_temp.size() && x_temp.size() != z_temp.size() && z_temp.size() != y_temp.size())
	{
		std::cout << "the size of point is incorrect!" << std::endl;
		return false;
	}
	else
	{
		std::cout << "the txt is created!" << std::endl;
		
	}
	std::ofstream outfile(save_file_path);
	for (int i = 0; i < x_temp.size(); i++)
	{
		std::string str;
		str = std::to_string(x_temp[i]) + ',' + std::to_string(y_temp[i]) + ',' + std::to_string(z_temp[i]);
		outfile << str << std::endl;
	}
	
	outfile.close();
	return true;
}
//����X,Y,Z������ǰ���λ�ļ��,�õ�ǰ���λ֮��������
double MaxInterval(double a, double b, double c)
{
	double max = a > b ? (a > c ? a : c) : (b > c ? b : c);
	return max;
}

//���X,Y,Z���Է����ϵ�ǰ���Ĳ�ֵ
double CurrentDelta(std::vector<double>delta, int current_index)
{
	double delta_temp = delta[current_index + 1] - delta[current_index];//���ÿ�εĲ�ֵ
	return delta_temp;
}

//���������ȷ���岹��������λ֮����Ҫ�������Լ��ķָ�����
int IntervalNum(double interval, double split_temp)
{
	int  interval_num_temp;
	double temp_a = interval / split_temp;
	double temp_b = (int)temp_a;
	double temp_c = temp_a - temp_b;
	if (temp_c == 0) {
		interval_num_temp = (int)temp_a - 1;

	}
	else {
		interval_num_temp = (int)temp_a;
	}
	return interval_num_temp;
}



//��ø��������ϵ������
void Get3dPoint(int num_point_temp,int num_3d_point_temp, std::vector<double>& all_every_point_temp, 
				std::vector<double>&x_temp, std::vector<double>&y_temp, std::vector<double>&z_temp)
{
	size_t j = 0;
	for (size_t i = 0; i < num_point_temp / 3; i = i + 1) {
		x_temp.push_back ( all_every_point_temp[j]);
		y_temp.push_back ( all_every_point_temp[j + 1]);
		z_temp.push_back(all_every_point_temp[j + 2]);
		j += 3;
	}

	for (int i = 0; i < num_3d_point_temp; i = i + 1)
	{
		std::cout << "old:" << x[i] << " " << y[i] << " " << z[i] << std::endl;
	}
}

//��þɵ�λ���ϵ�ά�Ⱥ��µ�λ���ϵ�ά��
void GetLen(int* new_num_3d_point_temp, int *num_3d_point_temp,int num_point_temp,double split_temp)
{
	*num_3d_point_temp = num_point_temp / 3;


	int increase_num = 0;
	int interval_num = 0;
	double max_interval = 0;
	for (int i = 0; i < *num_3d_point_temp - 1; i++)
	{
		double deltaX = CurrentDelta(x, i);
		double deltaY = CurrentDelta(y, i);
		double deltaZ = CurrentDelta(z, i);
		max_interval = MaxInterval(std::abs(deltaX), std::abs(deltaY), std::abs(deltaZ));
		interval_num = IntervalNum(max_interval,split_temp);
		increase_num += interval_num;
	}


	*new_num_3d_point_temp =*num_3d_point_temp + increase_num;
	std::cout << "old len:" << *num_3d_point_temp << std::endl;
	std::cout << "new len:" << *new_num_3d_point_temp << std::endl;
}

//�õ���ֵ����
int GetDelta(std::vector<double> &dx_temp, std::vector<double> &dy_temp, std::vector<double> &dz_temp,
			 std::vector<double>x, std::vector<double>y, std::vector<double>z,
			 int num_3d_point_temp,double split_temp)
{
	int delta_size = 0;
	std::cout << num_3d_point_temp << std::endl;
	for (int i = 0; i < num_3d_point_temp - 1; i++) 
	{
		double deltaX = CurrentDelta(x, i);
		double deltaY = CurrentDelta(y, i);
		double deltaZ = CurrentDelta(z, i);

		double max_interval = MaxInterval(std::abs(deltaX), std::abs(deltaY), std::abs(deltaZ));
		int interval = IntervalNum(max_interval,split_temp);
		double inter_m_x = (std::abs(deltaX) / max_interval) * split_temp;
		double inter_m_y = (std::abs(deltaY) / max_interval) * split_temp;
		double inter_m_z = (std::abs(deltaZ) / max_interval) * split_temp;

		double m_x = deltaX > 0 ? (x[i + 1] > x[i] ? inter_m_x * 1.0 : inter_m_x * -1.0) : inter_m_x * -1.0;
		double m_y = deltaY > 0 ? (y[i + 1] > y[i] ? inter_m_y * 1.0 : inter_m_y * -1.0) : inter_m_y * -1.0;
		double m_z = deltaZ > 0 ? (z[i + 1] > z[i] ? inter_m_z * 1.0 : inter_m_z * -1.0) : inter_m_z * -1.0;

		std::cout << "��ǰ���Ϊ:" << interval << std::endl;
		for (int j = 0; j < interval; j++) 
		{
			dx_temp.push_back(m_x);
			dy_temp.push_back(m_y);
			dz_temp.push_back(m_z);
			delta_size++;
		}
		
	}
	std::cout <<"deltaά��Ϊ��" << dx_temp.size() <<" "<<delta_size << std::endl;
	for (int i = 0; i < dx_temp.size(); i++) 
	{
		
		std::cout << "deltaΪ��" << dx_temp[i] << " " << dy_temp[i] << " " << dz_temp[i] << std::endl;
	}
	return delta_size;
}

void GetNew3dPoint(int num_3d_point_temp, double split_temp,
				   std::vector<double>& x_temp, std::vector<double>& y_temp, std::vector<double>& z_temp,
	               std::vector<double>& new_x_temp, std::vector<double>& new_y_temp, std::vector<double>& new_z_temp)
{
	int i = 0;
	for (i = 0; i < num_3d_point_temp - 1; i++)
	{
		double deltaX = CurrentDelta(x, i);
		double deltaY = CurrentDelta(y, i);
		double deltaZ = CurrentDelta(z, i);

		double max_interval = MaxInterval(std::abs(deltaX), std::abs(deltaY), std::abs(deltaZ));
		int interval = IntervalNum(max_interval,split_temp);
		double inter_m_x = (std::abs(deltaX) / max_interval) * split_temp;
		double inter_m_y = (std::abs(deltaY) / max_interval) * split_temp;
		double inter_m_z = (std::abs(deltaZ) / max_interval) * split_temp;

		double m_x = deltaX > 0 ? (x[i + 1] > x[i] ? inter_m_x * 1.0 : inter_m_x * -1.0) : inter_m_x * -1.0;
		double m_y = deltaY > 0 ? (y[i + 1] > y[i] ? inter_m_y * 1.0 : inter_m_y * -1.0) : inter_m_y * -1.0;
		double m_z = deltaZ > 0 ? (z[i + 1] > z[i] ? inter_m_z * 1.0 : inter_m_z * -1.0) : inter_m_z * -1.0;



		std::cout << "��ǰ���Ϊ:" << interval << std::endl;

		new_x_temp.push_back(x_temp[i]);
		new_y_temp.push_back(y_temp[i]);
		new_z_temp.push_back(z_temp[i]);
		for (int j = 1; j <= interval; j++)
		{
			new_x_temp.push_back(x_temp[i] + m_x * j);
			new_y_temp.push_back(y_temp[i] + m_y * j);
			new_z_temp.push_back(z_temp[i] + m_z * j);
		}
		//new_x_temp.push_back(x_temp[i+1]);
		//new_y_temp.push_back(y_temp[i+1]);
		//new_z_temp.push_back(z_temp[i+1]);
	}
	//�����һ������ѹ�����
	new_x_temp.push_back(x_temp[i]);
	new_y_temp.push_back(y_temp[i] );
	new_z_temp.push_back(z_temp[i] );
		
	std::cout << " now len��" << new_x_temp.size()<<std::endl;
	/*for (int ii = 0; ii < new_x_temp.size(); ii++)
		{
			std::cout << "old:" << new_x_temp[ii] << " " << new_y_temp[ii] << " " << new_z_temp[ii] << std::endl;
		}
	*/

}


