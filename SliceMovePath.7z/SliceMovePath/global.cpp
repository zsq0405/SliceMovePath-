#include"global.h"
int num_point = 0;
int new_num_point = 0;
int num_3d_point =0;
int new_num_3d_point = 0;
double split = 0.1;
std::vector<double> all_every_point(num_point);

std::vector<double>x(num_3d_point);
std::vector<double>y(num_3d_point);
std::vector<double>z(num_3d_point);

std::vector<double>new_x(new_num_3d_point);
std::vector<double>new_y(new_num_3d_point);
std::vector<double>new_z(new_num_3d_point);

std::vector<double>dx(new_num_3d_point);
std::vector<double>dy(new_num_3d_point);
std::vector<double>dz(new_num_3d_point);


